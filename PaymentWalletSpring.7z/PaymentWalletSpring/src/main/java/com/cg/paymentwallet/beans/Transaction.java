package com.cg.paymentwallet.beans;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Transaction {

	
	private String mobile;
	private String transactions;
	@Id
	private String myDate;
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getTransactions() {
		return transactions;
	}
	public void setTransactions(String transaction) {
		this.transactions = transaction;
	}
	public String getMyDate() {
		return myDate;
	}
	public void setMyDate(String myDate) {
		this.myDate = myDate;
	}
	
	
}
