package com.cg.paymentwallet.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.beans.Transaction;
import com.cg.paymentwallet.repo.ITransactionRepo;
import com.cg.paymentwallet.repo.IWalletRepo;

@Service
public class WalletServiceImpl implements IWalletService {

	
	@Autowired
	private IWalletRepo repo;
	
	@Autowired
	private ITransactionRepo repo1;
	
	/*@Autowired
	private Transaction transaction;*/
	
	@PersistenceContext
	private EntityManager entity;
	
	DateTimeFormatter formater = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
	
	@Override
	public void createAccount(Customer customer) {
		repo.save(customer);
		
	}

	@Override
	public Optional<Customer> showBalance(String mobileno) {
		
		
		return repo.findById(mobileno);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
	
		Optional<Customer> customer1 = repo.findById(sourceMobileNo);
		Optional<Customer> customer2 = repo.findById(targetMobileNo);
		
		BigDecimal senderBal =  customer1.get().getWallet().subtract(amount);
		BigDecimal receiverBal =  customer2.get().getWallet().add(amount);
		
		customer1.get().setWallet(senderBal);
		customer2.get().setWallet(receiverBal);
		
		Customer cust = repo.save(customer1.get());
		repo.save(customer2.get());
		
		Transaction transaction = new Transaction();
		transaction.setMobile(sourceMobileNo);
		transaction.setMyDate(LocalDateTime.now().format(formater));
		transaction.setTransactions(amount+" transfered to" +targetMobileNo+ " current balance "+senderBal);
		
		
		repo1.save(transaction);
		
		return cust;
		
		
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		
		Optional<Customer> customer = repo.findById(mobileNo);
		BigDecimal finalAmt =  customer.get().getWallet().add(amount);
		customer.get().setWallet(finalAmt);
		Customer cust = repo.save(customer.get());
		
		Transaction transaction = new Transaction();
		transaction.setMobile(mobileNo);
		transaction.setMyDate(LocalDateTime.now().format(formater));
		transaction.setTransactions(amount+" deposited current balance "+finalAmt);
		
		
		repo1.save(transaction);
		return cust;
		
	
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		
		Optional<Customer> customer = repo.findById(mobileNo);
		BigDecimal finalAmt =  customer.get().getWallet().subtract(amount);
		customer.get().setWallet(finalAmt);
		Customer cust = repo.save(customer.get());
		
		Transaction transaction = new Transaction();
		transaction.setMobile(mobileNo);
		transaction.setMyDate(LocalDateTime.now().format(formater));
		transaction.setTransactions(amount+" withdrawn current balance "+finalAmt);
		
		
		repo1.save(transaction);
		return cust;
	}

	@Override
	public List<Transaction> showTransaction(String mobile) {
		Query query = entity.createQuery("FROM Transaction where mobile=?");
		query.setParameter(0, mobile);
		List<Transaction> transactions = query.getResultList();
		return transactions;
	}
	
	
	

}
